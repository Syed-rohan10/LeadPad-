// payment-config.js
// ── Single place to configure payments/licensing. ──────────────────────────
// To switch providers, set ACTIVE_PROVIDER below and fill in its config.
//
//   "gumroad" — works today, verifies keys via Gumroad's API directly, no
//               backend needed.
//   "stripe"  — needs the companion leadpad-backend Cloudflare Worker
//               deployed first (see that project's README). Once deployed,
//               set stripe.verifyEndpoint below to its /verify-license URL.

const ACTIVE_PROVIDER = "gumroad"; // "gumroad" | "stripe"

const PROVIDER_CONFIG = {
  gumroad: {
    // Product ID (preferred — never changes even if you rename the
    // permalink later). Found in Gumroad: Product > Content tab > License
    // key section > "Use your product ID to verify licenses through the API".
    productId: "buvjNzKsRZcFvsvQo9OLVA==",
    // Fallback, only used if productId above is left empty.
    productPermalink: "xknqso"
  },
  stripe: {
    // Your leadpad-backend Worker's verify endpoint, e.g.:
    // "https://leadpad-license-server.yoursubdomain.workers.dev/verify-license"
    verifyEndpoint: "https://YOUR-WORKER-URL/verify-license"
  }
};

// Scripts to load, in order. Each one registers itself into
// self.PaymentProviders — see providers/gumroad.js or providers/stripe.js
// for the exact shape.
const PROVIDER_SCRIPTS = ["providers/gumroad.js", "providers/stripe.js"];
