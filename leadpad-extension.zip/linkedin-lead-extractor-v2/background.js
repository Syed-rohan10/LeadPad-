// background.js — service worker
// Owns all storage reads/writes so popup + content script never race each other.

// importScripts is synchronous, so this two-step load works: first pull in
// the config (which declares ACTIVE_PROVIDER, PROVIDER_CONFIG, and the list
// of provider script files), then load exactly the provider files it names.
importScripts("payment-config.js");
importScripts(...PROVIDER_SCRIPTS);

const FREE_DAILY_LIMIT = 5;

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

async function getState() {
  const data = await chrome.storage.local.get([
    "leads",
    "dailyCount",
    "lastResetDay",
    "isPremium",
    "licenseKey",
    "riskAcknowledged"
  ]);
  const leads = data.leads || [];
  const isPremium = !!data.isPremium;
  let dailyCount = data.dailyCount || 0;
  const key = todayKey();

  // Reset the counter if it's a new day
  if (data.lastResetDay !== key) {
    dailyCount = 0;
    await chrome.storage.local.set({ dailyCount: 0, lastResetDay: key });
  }

  return {
    leads,
    dailyCount,
    isPremium,
    licenseKey: data.licenseKey || "",
    riskAcknowledged: !!data.riskAcknowledged,
    remaining: isPremium ? Infinity : Math.max(0, FREE_DAILY_LIMIT - dailyCount),
    limit: FREE_DAILY_LIMIT
  };
}

async function addLead(lead) {
  const state = await getState();

  // Don't save anything until the person has been shown and acknowledged
  // the LinkedIn ToS risk disclaimer (see onboarding.html). This isn't
  // just a UI nicety — it's the checkpoint that makes sure informed
  // consent actually happened before any scraping does.
  if (!state.riskAcknowledged) {
    return { ok: false, reason: "risk_not_acknowledged", state };
  }

  // Check duplicates first — re-saving something already in the list
  // shouldn't be blocked by (or blamed on) the daily limit.
  const alreadySaved = state.leads.some((l) => l.profileUrl === lead.profileUrl);
  if (alreadySaved) {
    return { ok: false, reason: "duplicate", state };
  }

  if (!state.isPremium && state.dailyCount >= FREE_DAILY_LIMIT) {
    return { ok: false, reason: "limit_reached", state };
  }

  const newLead = { ...lead, savedAt: new Date().toISOString() };
  const leads = [newLead, ...state.leads];
  const dailyCount = state.isPremium ? state.dailyCount : state.dailyCount + 1;

  await chrome.storage.local.set({ leads, dailyCount, lastResetDay: todayKey() });
  const newState = await getState();
  return { ok: true, state: newState };
}

async function deleteLead(profileUrl) {
  const state = await getState();
  const leads = state.leads.filter((l) => l.profileUrl !== profileUrl);
  await chrome.storage.local.set({ leads });
  return getState();
}

async function clearLeads() {
  await chrome.storage.local.set({ leads: [] });
  return getState();
}

function toCsv(leads) {
  const headers = ["Name", "Title", "Company", "Location", "Profile URL", "Saved At"];
  const rows = leads.map((l) =>
    [l.name, l.title, l.company, l.location, l.profileUrl, l.savedAt]
      .map((cell) => csvCell(cell))
      .join(",")
  );
  return [headers.join(","), ...rows].join("\n");
}

// Prevent CSV injection: if a cell starts with =, +, -, or @, Excel/Sheets
// may interpret it as a formula when the file is opened. Prefixing with a
// single quote forces it to be treated as plain text. LinkedIn names/titles
// are attacker-influenceable (anyone can set their own LinkedIn headline),
// so this is a real, not hypothetical, risk for a scraping tool like this.
function csvCell(value) {
  let str = String(value || "");
  if (/^[=+\-@]/.test(str)) {
    str = `'${str}`;
  }
  return `"${str.replace(/"/g, '""')}"`;
}

async function verifyLicense(licenseKey) {
  const key = (licenseKey || "").trim();
  if (!key) return { ok: false, reason: "empty_key", state: await getState() };

  const provider = self.PaymentProviders && self.PaymentProviders[ACTIVE_PROVIDER];
  if (!provider) {
    console.error(`LeadPad: no payment provider registered for "${ACTIVE_PROVIDER}". Check payment-config.js.`);
    return { ok: false, reason: "provider_not_configured", state: await getState() };
  }

  try {
    const result = await provider.verify(key, PROVIDER_CONFIG[ACTIVE_PROVIDER] || {});

    if (result.valid) {
      await chrome.storage.local.set({ isPremium: true, licenseKey: key });
    }

    return { ok: result.valid, reason: result.reason, state: await getState() };
  } catch (err) {
    // Network failure, provider down, malformed response, etc. — don't
    // silently grant premium, just report verification couldn't complete.
    return { ok: false, reason: "network_error", state: await getState() };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case "GET_STATE": {
        sendResponse(await getState());
        break;
      }
      case "ADD_LEAD": {
        sendResponse(await addLead(message.lead));
        break;
      }
      case "DELETE_LEAD": {
        sendResponse(await deleteLead(message.profileUrl));
        break;
      }
      case "CLEAR_LEADS": {
        sendResponse(await clearLeads());
        break;
      }
      case "EXPORT_CSV": {
        const state = await getState();
        const csv = toCsv(state.leads);
        const dataUrl = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
        chrome.downloads.download({
          url: dataUrl,
          filename: `leadpad-leads-${todayKey()}.csv`,
          saveAs: true
        });
        sendResponse({ ok: true });
        break;
      }
      case "SET_LICENSE": {
        sendResponse(await verifyLicense(message.licenseKey));
        break;
      }
      default:
        sendResponse({ ok: false, reason: "unknown_message" });
    }
  })();
  return true; // keep the message channel open for the async response
});

// ── Periodic re-verification ────────────────────────────────────────────
// Gumroad has no webhook wired up here, so a refund/dispute after
// activation would otherwise never be re-checked. Stripe (via
// leadpad-backend) already revokes on webhook, but re-checking here too
// costs nothing and keeps both providers consistent. Runs once/day, well
// within any provider's rate limits for a single key.

const REVALIDATE_ALARM = "leadpad-revalidate-license";

chrome.runtime.onInstalled.addListener((details) => {
  chrome.alarms.create(REVALIDATE_ALARM, { periodInMinutes: 60 * 24 });

  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== REVALIDATE_ALARM) return;

  const { isPremium, licenseKey } = await chrome.storage.local.get(["isPremium", "licenseKey"]);
  if (!isPremium || !licenseKey) return;

  const provider = self.PaymentProviders && self.PaymentProviders[ACTIVE_PROVIDER];
  if (!provider) return;

  try {
    const result = await provider.verify(licenseKey, PROVIDER_CONFIG[ACTIVE_PROVIDER] || {});
    if (!result.valid) {
      await chrome.storage.local.set({ isPremium: false });
    }
  } catch {
    // Network hiccup or provider outage — don't revoke on a failed check,
    // only revoke on an explicit "not valid" answer.
  }
});

