// providers/stripe.js
//
// Pairs with the leadpad-backend Cloudflare Worker (Stripe Checkout +
// webhook + D1 database). See that project's README for deployment steps.
//
// To activate this provider:
//   1. Deploy leadpad-backend and copy its Worker URL.
//   2. In payment-config.js: set ACTIVE_PROVIDER = "stripe" and put your
//      Worker's /verify-license URL into PROVIDER_CONFIG.stripe.verifyEndpoint.
//   3. Add your Worker's domain to host_permissions in manifest.json.
//
// Expected backend response shape: { valid: boolean, reason?: string }

self.PaymentProviders = self.PaymentProviders || {};

self.PaymentProviders.stripe = {
  async verify(licenseKey, config) {
    const response = await fetch(config.verifyEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ licenseKey })
    });

    if (!response.ok) {
      return { valid: false, reason: "server_error" };
    }

    // Expected backend response shape: { valid: boolean, reason?: string }
    const data = await response.json();
    return { valid: !!data.valid, reason: data.reason };
  }
};
