// providers/gumroad.js
// A "provider" just needs to register an object with a `verify(licenseKey,
// config)` method on self.PaymentProviders. It must return:
//   { valid: boolean, reason?: string }
// Throwing (or a rejected fetch) is treated as a network/unknown error by
// the caller in background.js — don't catch-and-return-valid-true on error.

self.PaymentProviders = self.PaymentProviders || {};

self.PaymentProviders.gumroad = {
  async verify(licenseKey, config) {
    // Gumroad's verify API accepts either product_permalink or product_id —
    // product_id is preferred since it never changes even if you rename
    // your product's permalink later.
    const body = { license_key: licenseKey, increment_uses_count: "false" };
    if (config.productId) {
      body.product_id = config.productId;
    } else {
      body.product_permalink = config.productPermalink;
    }

    const response = await fetch("https://api.gumroad.com/v2/licenses/verify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(body)
    });

    const data = await response.json();
    const purchase = data.purchase || {};

    const valid =
      data.success === true &&
      !purchase.refunded &&
      !purchase.disputed &&
      !purchase.chargebacked;

    if (!valid && data.success === false) {
      return { valid: false, reason: "invalid_key" };
    }
    if (!valid) {
      return { valid: false, reason: "refunded_or_disputed" };
    }
    return { valid: true };
  }
};
