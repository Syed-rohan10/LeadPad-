const ackCheckbox = document.getElementById("ackCheckbox");
const continueBtn = document.getElementById("continueBtn");

ackCheckbox.addEventListener("change", () => {
  continueBtn.disabled = !ackCheckbox.checked;
});

continueBtn.addEventListener("click", async () => {
  await chrome.storage.local.set({
    riskAcknowledged: true,
    riskAcknowledgedAt: new Date().toISOString()
  });
  window.close();
});
