// content.js — runs on linkedin.com/in/* (profile pages) and
// linkedin.com/search/results/people/* (search results).
//
// NOTE ON SELECTORS: LinkedIn changes its DOM/class names frequently and
// they're obfuscated, so the selectors below use resilient patterns
// (semantic tags, aria attributes, text position) rather than brittle class
// names, and fall back gracefully if something isn't found. Expect to
// revisit these selectors occasionally.
//
// NOTE ON SCOPE: this only reads text that is already visible on the
// rendered page (a logged-in user's own view) — it does not query any
// LinkedIn API, bypass any paywall, or automate connection/messaging
// actions. Keep it that way to stay clear of ToS automation rules.

function isProfilePage() {
  return /\/in\/[^/]+\/?$/.test(location.pathname);
}

function extractProfileFromPage() {
  const name =
    document.querySelector("h1")?.innerText?.trim() || "";

  // The headline usually sits directly under the h1 as the next text block.
  const title =
    document.querySelector(".text-body-medium")?.innerText?.trim() ||
    document.querySelector('[data-generated-suggestion-target]')?.innerText?.trim() ||
    "";

  const geo =
    document.querySelector(".text-body-small.inline")?.innerText?.trim() || "";

  // Company: best-effort from the first experience entry, if visible on page.
  const company =
    document.querySelector('section[id*="experience"] li a span[aria-hidden="true"]')
      ?.innerText?.trim() || "";

  return {
    name,
    title,
    company,
    location: geo,
    profileUrl: window.location.href.split("?")[0]
  };
}

function createSaveButton() {
  const btn = document.createElement("button");
  btn.id = "leadpad-save-btn";
  btn.className = "leadpad-btn";
  btn.textContent = "+ Save lead";
  btn.addEventListener("click", async () => {
    const lead = extractProfileFromPage();
    lead.profileUrl = window.location.href.split("?")[0];

    if (!lead.name) {
      showToast("Couldn't find a profile name on this page.", "error");
      return;
    }

    btn.disabled = true;
    btn.textContent = "Saving…";

    const res = await chrome.runtime.sendMessage({ type: "ADD_LEAD", lead });

    if (res.ok) {
      btn.textContent = "✓ Saved";
      btn.classList.add("leadpad-btn--saved");
      showToast(`Saved ${lead.name} to LeadPad`, "success");
    } else if (res.reason === "duplicate") {
      btn.textContent = "Already saved";
      showToast("This profile is already in your leads.", "info");
    } else if (res.reason === "limit_reached") {
      btn.disabled = false;
      btn.textContent = "+ Save lead";
      showToast("Daily free limit reached. Upgrade for unlimited saves.", "error");
    } else if (res.reason === "risk_not_acknowledged") {
      btn.disabled = false;
      btn.textContent = "+ Save lead";
      showToast("Open the LeadPad extension icon to accept the terms first.", "error");
    }
  });
  return btn;
}

function showToast(message, kind) {
  const existing = document.getElementById("leadpad-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "leadpad-toast";
  toast.className = `leadpad-toast leadpad-toast--${kind}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add("leadpad-toast--visible"), 10);
  setTimeout(() => {
    toast.classList.remove("leadpad-toast--visible");
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

function injectProfileButton() {
  if (document.getElementById("leadpad-save-btn")) return;
  const anchor = document.querySelector("h1")?.closest("section");
  if (!anchor) return;

  const btn = createSaveButton();
  const wrapper = document.createElement("div");
  wrapper.className = "leadpad-floating-wrapper";
  wrapper.appendChild(btn);
  document.body.appendChild(wrapper);
}

// --- Search results page: lightweight checkbox + bulk-save bar ---

function injectSearchResultsUI() {
  const results = document.querySelectorAll('[data-view-name="search-entity-result-universal-template"], .reusable-search__result-container, li.reusable-search__result-container');
  if (!results.length) return;

  results.forEach((card) => {
    if (card.querySelector(".leadpad-checkbox")) return;
    const link = card.querySelector('a[href*="/in/"]');
    if (!link) return;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "leadpad-checkbox";
    checkbox.dataset.profileUrl = link.href.split("?")[0];
    checkbox.dataset.name = card.querySelector("span[aria-hidden='true']")?.innerText?.trim() || "";
    card.style.position = "relative";
    card.appendChild(checkbox);
  });

  injectBulkBar();
}

function injectBulkBar() {
  if (document.getElementById("leadpad-bulk-bar")) return;

  const bar = document.createElement("div");
  bar.id = "leadpad-bulk-bar";
  bar.className = "leadpad-bulk-bar";
  bar.innerHTML = `
    <span class="leadpad-bulk-bar__count">0 selected</span>
    <button class="leadpad-btn leadpad-btn--small" id="leadpad-bulk-save">Save selected</button>
  `;
  document.body.appendChild(bar);

  document.addEventListener("change", (e) => {
    if (!e.target.classList.contains("leadpad-checkbox")) return;
    const count = document.querySelectorAll(".leadpad-checkbox:checked").length;
    bar.querySelector(".leadpad-bulk-bar__count").textContent = `${count} selected`;
  });

  bar.querySelector("#leadpad-bulk-save").addEventListener("click", async () => {
    const checked = document.querySelectorAll(".leadpad-checkbox:checked");
    if (!checked.length) {
      showToast("Select at least one profile first.", "info");
      return;
    }
    let saved = 0;
    let blocked = false;
    let needsAck = false;
    for (const box of checked) {
      const lead = {
        name: box.dataset.name,
        title: "",
        company: "",
        location: "",
        profileUrl: box.dataset.profileUrl
      };
      const res = await chrome.runtime.sendMessage({ type: "ADD_LEAD", lead });
      if (res.ok) saved++;
      if (res.reason === "limit_reached") {
        blocked = true;
        break;
      }
      if (res.reason === "risk_not_acknowledged") {
        needsAck = true;
        break;
      }
    }
    if (needsAck) {
      showToast("Open the LeadPad extension icon to accept the terms first.", "error");
    } else {
      showToast(
        blocked
          ? `Saved ${saved}, then hit your daily free limit. Upgrade for more.`
          : `Saved ${saved} lead${saved === 1 ? "" : "s"} to LeadPad`,
        blocked ? "error" : "success"
      );
    }
  });
}

function debounce(fn, delayMs) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delayMs);
  };
}

function init() {
  if (isProfilePage()) {
    injectProfileButton();
    // Profile pages render async sections after initial load. Debounced so
    // our own injected button/wrapper doesn't retrigger an immediate rescan.
    const observer = new MutationObserver(debounce(injectProfileButton, 400));
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    injectSearchResultsUI();
    const observer = new MutationObserver(debounce(injectSearchResultsUI, 400));
    observer.observe(document.body, { childList: true, subtree: true });
  }
}

init();
