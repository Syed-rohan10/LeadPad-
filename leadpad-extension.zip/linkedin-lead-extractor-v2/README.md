# LeadPad — LinkedIn Lead Extractor

A Chrome extension (Manifest V3) that lets a user save LinkedIn profiles as
leads with one click and export them to CSV. Free tier: 5 saves/day.
Premium: unlimited, gated by a license key.

## Load it locally (for testing)

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this folder.
4. Visit any `linkedin.com/in/...` profile — a **+ Save lead** button
   appears bottom-right. On a people search results page, checkboxes appear
   on each result plus a **Save selected** bar.
5. Click the extension icon to see saved leads and export CSV.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | Extension config, permissions, entry points |
| `content.js` / `content.css` | Injected into LinkedIn pages — extracts profile data, adds the save button / bulk bar |
| `background.js` | Service worker — owns storage, daily limit logic, CSV generation, dispatches license checks to the active payment provider |
| `payment-config.js` | Pick your active payment provider and its settings here |
| `providers/gumroad.js` | Working Gumroad license verification (default provider) |
| `providers/stripe.js` | Stripe provider — pairs with the leadpad-backend Worker |
| `popup.html/css/js` | The toolbar popup — lead list, export, upgrade prompt, risk-acknowledgment gate |
| `options.html/css/js` | Settings page — plan status, license key activation |
| `onboarding.html/js` | First-install screen — LinkedIn ToS risk disclaimer, must be accepted before any lead can be saved |
| `terms.html` / `privacy.html` | In-extension pages linked from onboarding (same content as the root `TERMS_OF_SERVICE.md` / `PRIVACY_POLICY.md`) |

## Before you ship this

- **Selectors will drift.** LinkedIn's DOM/class names change often and are
  obfuscated — the extraction selectors in `content.js` are best-effort and
  you'll likely need to adjust them after testing on live pages.
- **Stay read-only.** This only reads what's already visible to a logged-in
  user and never automates connects/messages/scrolling. Keep it that way —
  LinkedIn actively enforces against automation, and accounts can get
  restricted.
- **Payments are pluggable — swap or add providers without touching core code.**
  Everything payment-related lives in:
  - `payment-config.js` — pick `ACTIVE_PROVIDER` and fill in that provider's
    settings.
  - `providers/gumroad.js` — working Gumroad integration (active by
    default, no backend needed). Verifies keys via Gumroad's
    `/v2/licenses/verify` API.
  - `providers/stripe.js` — pairs with the companion **leadpad-backend**
    project (Cloudflare Worker + D1 database that turns Stripe payments
    into license keys). Deploy that first, then set
    `PROVIDER_CONFIG.stripe.verifyEndpoint` to its `/verify-license` URL
    and flip `ACTIVE_PROVIDER` to `"stripe"`.

  To finish the Gumroad setup:
  1. Create a product at gumroad.com and turn on **"Generate a unique
     license key per sale"** in the product's Content tab.
  2. Copy the product permalink (end of the product URL) into
     `productPermalink` under `gumroad:` in `payment-config.js`.
  3. Put your Gumroad product page URL into `upgradeLink.href` in
     `options.js`.
  4. Test with a real (or Gumroad test-mode) purchase — Gumroad emails the
     buyer a license key, which they paste into the extension's Settings
     page.

  To switch to Stripe once you've deployed leadpad-backend:
  1. Set `ACTIVE_PROVIDER = "stripe"` and fill in `verifyEndpoint` in
     `payment-config.js`.
  2. Add your Worker's domain to `host_permissions` in `manifest.json`.
  3. Point `upgradeLink.href` in `options.js` at your Stripe payment page.
- **Icons are placeholders.** Swap `icons/icon16.png`, `48.png`, `128.png`
  for real branding before publishing.
- **Privacy policy needs external hosting too.** `PRIVACY_POLICY.md` /
  `TERMS_OF_SERVICE.md` (and their in-app `privacy.html` / `terms.html`
  twins) are ready-to-use — fill in the date and contact email, then also
  publish the privacy policy somewhere public (GitHub Pages works fine)
  since the Chrome Web Store listing requires a privacy policy URL outside
  the extension itself.
- **LinkedIn ToS risk disclaimer is enforced, not just documented.** On
  first install, `onboarding.html` opens automatically and requires
  checking an acknowledgment box before `background.js` will save any
  lead (`ADD_LEAD` is refused with `reason: "risk_not_acknowledged"` until
  `chrome.storage.local.riskAcknowledged` is `true`). If you edit the risk
  language, update it in three places: `onboarding.html`, `terms.html`,
  and `TERMS_OF_SERVICE.md` — they currently say the same thing in three
  formats (in-app gate, in-app terms page, and the standalone doc for
  external hosting).
- **Suggested Chrome Web Store listing language** (reduces review friction
  around the LinkedIn data point): *"Saves only information already
  visible to the signed-in user on pages they browse. Does not automate
  messaging, connection requests, or bypass LinkedIn restrictions in any
  way."*

## Publishing to the Chrome Web Store

1. Zip the folder contents (not the folder itself).
2. Create a one-time $5 developer account at
   https://chrome.google.com/webstore/devconsole
3. Upload the zip, fill in the listing (screenshots, description, privacy
   policy URL), and submit for review.
