const planStatusEl = document.getElementById("planStatus");
const licenseInput = document.getElementById("licenseInput");
const activateBtn = document.getElementById("activateBtn");
const licenseMsg = document.getElementById("licenseMsg");
const upgradeLink = document.getElementById("upgradeLink");

// Your Gumroad product page — shown to free users who hit the daily limit.
upgradeLink.href = "https://facttrio.gumroad.com/l/xknqso";

async function refreshPlanStatus() {
  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  if (state.isPremium) {
    planStatusEl.textContent = "Premium — unlimited saves active";
    planStatusEl.classList.add("plan-status--premium");
  } else {
    planStatusEl.textContent = `Free plan — ${state.remaining} of ${state.limit} saves left today`;
  }
}

activateBtn.addEventListener("click", async () => {
  const licenseKey = licenseInput.value.trim();
  if (!licenseKey) return;

  activateBtn.disabled = true;
  activateBtn.textContent = "Checking…";

  const res = await chrome.runtime.sendMessage({ type: "SET_LICENSE", licenseKey });

  activateBtn.disabled = false;
  activateBtn.textContent = "Activate";

  if (res.ok) {
    licenseMsg.textContent = "Premium activated. Thanks for upgrading!";
    licenseMsg.className = "license-msg license-msg--success";
    refreshPlanStatus();
  } else if (res.reason === "network_error") {
    licenseMsg.textContent = "Couldn't reach the license server. Check your connection and try again.";
    licenseMsg.className = "license-msg license-msg--error";
  } else {
    licenseMsg.textContent = "That key doesn't look right. Double-check and try again.";
    licenseMsg.className = "license-msg license-msg--error";
  }
});

refreshPlanStatus();
