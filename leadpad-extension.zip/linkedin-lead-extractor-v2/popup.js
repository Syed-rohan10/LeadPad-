const leadsListEl = document.getElementById("leadsList");
const emptyStateEl = document.getElementById("emptyState");
const limitFillEl = document.getElementById("limitFill");
const limitTextEl = document.getElementById("limitText");
const exportBtn = document.getElementById("exportBtn");
const clearBtn = document.getElementById("clearBtn");
const settingsBtn = document.getElementById("settingsBtn");
const riskGateEl = document.getElementById("riskGate");
const mainViewEl = document.getElementById("mainView");
const reviewTermsBtn = document.getElementById("reviewTermsBtn");

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str || "";
  return div.innerHTML;
}

function renderLeads(leads) {
  leadsListEl.innerHTML = "";
  emptyStateEl.style.display = leads.length ? "none" : "block";
  leadsListEl.style.display = leads.length ? "block" : "none";

  leads.forEach((lead) => {
    const li = document.createElement("li");
    li.className = "lead-card";
    const metaParts = [lead.title, lead.company, lead.location].filter(Boolean).join(" · ");
    li.innerHTML = `
      <div>
        <p class="lead-card__name">${escapeHtml(lead.name)}</p>
        <p class="lead-card__meta">${escapeHtml(metaParts || "No extra details captured")}</p>
      </div>
      <button class="lead-card__remove" title="Remove" data-url="${escapeHtml(lead.profileUrl)}">✕</button>
    `;
    leadsListEl.appendChild(li);
  });

  leadsListEl.querySelectorAll(".lead-card__remove").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const state = await chrome.runtime.sendMessage({
        type: "DELETE_LEAD",
        profileUrl: btn.dataset.url
      });
      render(state);
    });
  });
}

function renderLimit(state) {
  if (state.isPremium) {
    limitFillEl.style.width = "100%";
    limitTextEl.textContent = "Premium — unlimited saves";
    limitTextEl.classList.add("limit-bar__text--premium");
    removeUpgradeBanner();
    return;
  }

  const used = state.limit - state.remaining;
  const pct = Math.min(100, (used / state.limit) * 100);
  limitFillEl.style.width = `${pct}%`;
  limitTextEl.textContent = `${used} / ${state.limit} saved today`;

  if (state.remaining === 0) {
    showUpgradeBanner();
  } else {
    removeUpgradeBanner();
  }
}

function showUpgradeBanner() {
  if (document.getElementById("upgradeBanner")) return;
  const banner = document.createElement("div");
  banner.id = "upgradeBanner";
  banner.className = "upgrade-banner";
  banner.innerHTML = `
    <span>Daily free limit reached.</span>
    <button id="upgradeBtn">Upgrade</button>
  `;
  document.querySelector(".limit-bar").insertAdjacentElement("afterend", banner);
  banner.querySelector("#upgradeBtn").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}

function removeUpgradeBanner() {
  document.getElementById("upgradeBanner")?.remove();
}

function render(state) {
  if (!state.riskAcknowledged) {
    riskGateEl.style.display = "block";
    mainViewEl.style.display = "none";
    return;
  }
  riskGateEl.style.display = "none";
  mainViewEl.style.display = "block";

  renderLeads(state.leads);
  renderLimit(state);
  exportBtn.disabled = state.leads.length === 0;
}

async function init() {
  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  render(state);
}

exportBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "EXPORT_CSV" });
});

clearBtn.addEventListener("click", async () => {
  const confirmed = confirm("Remove all saved leads? This can't be undone.");
  if (!confirmed) return;
  const state = await chrome.runtime.sendMessage({ type: "CLEAR_LEADS" });
  render(state);
});

settingsBtn.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

reviewTermsBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
  window.close();
});

init();
